
export interface Response{

    results:ImageInfo[]

}

export interface ImageInfo{
 
    title:string;
    thumbnail:string
}