import { useState } from 'react'
import './App.css'
import { ImageInfo,Response } from './interfaces/Response';
import ImageTemplet from './components/ImageCard';

function App() {
  
  const [userValue,setUserValue]  = useState<string>('');
  const  [listImageData,setListImageData] = useState<ImageInfo[]>([]);
  const [loading,setLoading] = useState<boolean>(false);

  const fetchData=async()=>{

    try{
      setLoading(true);

    const response = await fetch(`https://api.openverse.org/v1/images/?q=${userValue}`);

    const data = await response.json();

    const finalData = data as Response
    finalData.results.map((value,index)=>
      setListImageData((prevData)=>[...prevData,value])
    )
    
    setLoading(false);
    }catch(err){
      console.log(err);
      setLoading(false);
    }

  }

  const displayImages = ()=>{

    return( listImageData.map((value,index)=>(
       <ImageTemplet key={index} data={value}/>
    )))

  }

  return (
    <div>
      <input value={userValue} onChange={(e)=>setUserValue(e.target.value) }/>
      <button onClick={fetchData}>Search</button>

      <div  style={{display:'grid',gridTemplateColumns:'250px 250px 250px',gridAutoRows:'250px'}}>
        {listImageData && displayImages()}
      </div>
      {loading && <h2>Loading...........</h2>}
    
</div>
  )
}

export default App
