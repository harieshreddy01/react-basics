import { ImageInfo } from "../interfaces/Response"

const ImageTemplet = ({data}:{data:ImageInfo})=>{

    return(
        <div  style={{display:'flex',flexDirection:'column'}}>
            <img style={{width:'200px',height:'200px'}}src={data.thumbnail}/>
            <h2>{data.title}</h2>
        </div>
    )

}

export default ImageTemplet;